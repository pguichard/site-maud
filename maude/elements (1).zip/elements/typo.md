# les typos
- titres : GFS Didot
- labeur : Instrument Sans
- tailles : 
    - corps : 18px
    - titre section : 28px
    - titre sous section 24px
    - menu : 20px